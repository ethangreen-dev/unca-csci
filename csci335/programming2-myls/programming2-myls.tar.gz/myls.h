#ifndef MYLS_H
#define MYLS_H

void print_dir(char *dirp);

#endif