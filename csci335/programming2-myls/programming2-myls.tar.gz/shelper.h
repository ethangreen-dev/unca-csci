#ifndef SHELPER_H
#define SHELPER_H

int smaller_than(char *string1, char *string2);

#endif