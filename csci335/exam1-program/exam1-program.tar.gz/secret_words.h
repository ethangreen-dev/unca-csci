#ifndef secret_words_h
#define secret_words_h

int number_of_secret_words();
char * get_secret_word(int i);

#endif /* secret_words.h */
